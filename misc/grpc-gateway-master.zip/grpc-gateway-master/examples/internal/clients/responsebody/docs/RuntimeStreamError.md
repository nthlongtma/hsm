# RuntimeStreamError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GrpcCode** | **int32** |  | [optional] [default to null]
**HttpCode** | **int32** |  | [optional] [default to null]
**Message** | **string** |  | [optional] [default to null]
**HttpStatus** | **string** |  | [optional] [default to null]
**Details** | [**[]ProtobufAny**](protobufAny.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


